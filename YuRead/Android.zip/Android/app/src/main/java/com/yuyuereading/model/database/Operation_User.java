package com.yuyuereading.model.database;

/**
 * 对WantRead列表进行操作
 * 数据库操作类
 */

public class Operation_User {
}
